import { useState } from "react";
import { useParams, useNavigate } from "react-router";
import { Plus, MapPin, Clock, DollarSign, Calendar, GripVertical, Trash2 } from "lucide-react";

interface Activity {
  id: string;
  name: string;
  time: string;
  duration: string;
  cost: number;
  type: string;
}

interface Stop {
  id: string;
  city: string;
  country: string;
  startDate: string;
  endDate: string;
  activities: Activity[];
}

export function ItineraryBuilder() {
  const { tripId } = useParams();
  const navigate = useNavigate();

  const [stops, setStops] = useState<Stop[]>([
    {
      id: "1",
      city: "Paris",
      country: "France",
      startDate: "2026-06-15",
      endDate: "2026-06-20",
      activities: [
        { id: "a1", name: "Visit Eiffel Tower", time: "09:00", duration: "3h", cost: 30, type: "Sightseeing" },
        { id: "a2", name: "Louvre Museum Tour", time: "14:00", duration: "4h", cost: 45, type: "Museum" },
      ]
    },
    {
      id: "2",
      city: "Rome",
      country: "Italy",
      startDate: "2026-06-21",
      endDate: "2026-06-25",
      activities: [
        { id: "a3", name: "Colosseum Visit", time: "10:00", duration: "2h", cost: 25, type: "Sightseeing" },
        { id: "a4", name: "Vatican Museums", time: "15:00", duration: "3h", cost: 35, type: "Museum" },
      ]
    }
  ]);

  const [showAddStop, setShowAddStop] = useState(false);

  return (
    <div className="p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Itinerary Builder</h1>
            <p className="text-gray-600">Plan your route and activities</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => navigate(`/trip/${tripId}`)}
              className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors"
            >
              Back to Trip
            </button>
            <button
              onClick={() => setShowAddStop(true)}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Add Stop
            </button>
          </div>
        </div>

        {/* Timeline */}
        <div className="space-y-8">
          {stops.map((stop, index) => (
            <div key={stop.id} className="relative">
              {/* Connection Line */}
              {index < stops.length - 1 && (
                <div className="absolute left-6 top-20 bottom-0 w-0.5 bg-blue-200" />
              )}

              {/* Stop Card */}
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                {/* Stop Header */}
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6">
                  <div className="flex items-center gap-4">
                    <div className="bg-white text-blue-600 w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <h2 className="text-2xl font-bold">{stop.city}, {stop.country}</h2>
                      <div className="flex items-center gap-2 mt-1 opacity-90">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(stop.startDate).toLocaleDateString()} - {new Date(stop.endDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <button className="p-2 hover:bg-white/20 rounded-lg transition-colors">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {/* Activities */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-gray-900">Activities</h3>
                    <button
                      onClick={() => navigate("/activities")}
                      className="text-blue-600 hover:underline text-sm flex items-center gap-1"
                    >
                      <Plus className="w-4 h-4" />
                      Add Activity
                    </button>
                  </div>

                  <div className="space-y-3">
                    {stop.activities.map((activity) => (
                      <div key={activity.id} className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:border-blue-300 transition-colors">
                        <GripVertical className="w-5 h-5 text-gray-400 cursor-move" />
                        <div className="flex-1">
                          <h4 className="font-bold text-gray-900">{activity.name}</h4>
                          <div className="flex items-center gap-4 mt-1 text-sm text-gray-600">
                            <span className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {activity.time} ({activity.duration})
                            </span>
                            <span className="flex items-center gap-1">
                              <DollarSign className="w-4 h-4" />
                              ${activity.cost}
                            </span>
                            <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">
                              {activity.type}
                            </span>
                          </div>
                        </div>
                        <button className="p-2 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-5 h-5 text-red-600" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Add Stop Modal */}
        {showAddStop && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Add New Stop</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="City name"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <input
                  type="text"
                  placeholder="Country"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="date"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <input
                    type="date"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setShowAddStop(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => setShowAddStop(false)}
                  className="flex-1 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Add Stop
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
