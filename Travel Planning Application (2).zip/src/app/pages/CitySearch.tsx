import { useState } from "react";
import { Search, MapPin, Globe, Star, Plus } from "lucide-react";

interface City {
  id: string;
  name: string;
  country: string;
  region: string;
  description: string;
  image: string;
  rating: number;
}

export function CitySearch() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRegion, setSelectedRegion] = useState("All");

  const cities: City[] = [
    {
      id: "1",
      name: "Paris",
      country: "France",
      region: "Europe",
      description: "The City of Light, famous for art, culture, and romance",
      image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600&h=400&fit=crop",
      rating: 4.8
    },
    {
      id: "2",
      name: "Tokyo",
      country: "Japan",
      region: "Asia",
      description: "A blend of traditional and modern culture",
      image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600&h=400&fit=crop",
      rating: 4.9
    },
    {
      id: "3",
      name: "New York",
      country: "USA",
      region: "North America",
      description: "The city that never sleeps",
      image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=600&h=400&fit=crop",
      rating: 4.7
    },
    {
      id: "4",
      name: "Dubai",
      country: "UAE",
      region: "Middle East",
      description: "Modern luxury and desert adventures",
      image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600&h=400&fit=crop",
      rating: 4.6
    },
    {
      id: "5",
      name: "Barcelona",
      country: "Spain",
      region: "Europe",
      description: "Stunning architecture and Mediterranean vibes",
      image: "https://images.unsplash.com/photo-1583422409516-2895a77efded?w=600&h=400&fit=crop",
      rating: 4.8
    },
    {
      id: "6",
      name: "Bali",
      country: "Indonesia",
      region: "Asia",
      description: "Tropical paradise with rich culture",
      image: "https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=600&h=400&fit=crop",
      rating: 4.9
    },
    {
      id: "7",
      name: "Sydney",
      country: "Australia",
      region: "Oceania",
      description: "Iconic harbor and vibrant city life",
      image: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=600&h=400&fit=crop",
      rating: 4.7
    },
    {
      id: "8",
      name: "Santorini",
      country: "Greece",
      region: "Europe",
      description: "White-washed buildings and stunning sunsets",
      image: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=600&h=400&fit=crop",
      rating: 4.9
    }
  ];

  const regions = ["All", "Europe", "Asia", "North America", "South America", "Middle East", "Africa", "Oceania"];

  const filteredCities = cities.filter(city => {
    const matchesSearch = city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         city.country.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRegion = selectedRegion === "All" || city.region === selectedRegion;
    return matchesSearch && matchesRegion;
  });

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Explore Cities</h1>
          <p className="text-gray-600">Discover amazing destinations around the world</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search cities or countries..."
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {regions.map(region => (
                <option key={region} value={region}>{region}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Cities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCities.map(city => (
            <div key={city.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <img src={city.image} alt={city.name} className="w-full h-48 object-cover" />
              <div className="p-6">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">{city.name}</h3>
                    <p className="text-gray-600 flex items-center gap-1 mt-1">
                      <Globe className="w-4 h-4" />
                      {city.country}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 bg-yellow-100 px-2 py-1 rounded">
                    <Star className="w-4 h-4 text-yellow-600 fill-yellow-600" />
                    <span className="font-bold text-yellow-700">{city.rating}</span>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4">{city.description}</p>
                <div className="flex gap-2">
                  <button className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2">
                    <Plus className="w-4 h-4" />
                    Add to Trip
                  </button>
                  <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors">
                    <MapPin className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredCities.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No cities found matching your search</p>
          </div>
        )}
      </div>
    </div>
  );
}
