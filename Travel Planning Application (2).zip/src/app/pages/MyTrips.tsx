import { useNavigate } from "react-router";
import { Plus, Calendar, MapPin, Edit, Trash2 } from "lucide-react";

export function MyTrips() {
  const navigate = useNavigate();

  const trips = [
    {
      id: "1",
      name: "European Adventure",
      description: "Exploring the culture and history of Europe",
      startDate: "Jun 15, 2026",
      endDate: "Jun 30, 2026",
      destinations: 3,
      image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&h=400&fit=crop"
    },
    {
      id: "2",
      name: "Southeast Asia Explorer",
      description: "Beach hopping and temple visits",
      startDate: "Aug 10, 2026",
      endDate: "Aug 25, 2026",
      destinations: 3,
      image: "https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=800&h=400&fit=crop"
    },
    {
      id: "3",
      name: "Australia Road Trip",
      description: "Coast to coast adventure",
      startDate: "Oct 5, 2026",
      endDate: "Oct 20, 2026",
      destinations: 5,
      image: "https://images.unsplash.com/photo-1523482580672-f109ba8cb9be?w=800&h=400&fit=crop"
    },
    {
      id: "4",
      name: "South America Discovery",
      description: "Ancient ruins and rainforests",
      startDate: "Dec 1, 2026",
      endDate: "Dec 18, 2026",
      destinations: 4,
      image: "https://images.unsplash.com/photo-1531065208531-4036c0dba3ca?w=800&h=400&fit=crop"
    }
  ];

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">My Trips</h1>
            <p className="text-gray-600">Manage and view all your travel plans</p>
          </div>
          <button
            onClick={() => navigate("/create-trip")}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Create New Trip
          </button>
        </div>

        {/* Trips Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trips.map((trip) => (
            <div key={trip.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <img src={trip.image} alt={trip.name} className="w-full h-48 object-cover" />
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{trip.name}</h3>
                <p className="text-gray-600 mb-4 text-sm">{trip.description}</p>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>{trip.startDate} - {trip.endDate}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span>{trip.destinations} destinations</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => navigate(`/trip/${trip.id}`)}
                    className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    View Trip
                  </button>
                  <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors">
                    <Edit className="w-5 h-5 text-gray-600" />
                  </button>
                  <button className="p-2 border border-gray-300 rounded-lg hover:bg-red-50 transition-colors">
                    <Trash2 className="w-5 h-5 text-red-600" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
