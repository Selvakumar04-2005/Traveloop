import { useNavigate } from "react-router";
import { Plus, MapPin, Calendar, DollarSign, TrendingUp } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";

export function Dashboard() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const recentTrips = [
    {
      id: "1",
      name: "European Adventure",
      destinations: "Paris → Rome → Barcelona",
      dates: "Jun 15 - Jun 30, 2026",
      budget: "$3,500",
      image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&h=400&fit=crop"
    },
    {
      id: "2",
      name: "Southeast Asia Explorer",
      destinations: "Bangkok → Bali → Singapore",
      dates: "Aug 10 - Aug 25, 2026",
      budget: "$2,800",
      image: "https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=800&h=400&fit=crop"
    }
  ];

  const recommendedDestinations = [
    { name: "Tokyo, Japan", image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&h=300&fit=crop" },
    { name: "Santorini, Greece", image: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=400&h=300&fit=crop" },
    { name: "Dubai, UAE", image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=400&h=300&fit=crop" },
    { name: "New York, USA", image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=400&h=300&fit=crop" }
  ];

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t.dashboard.welcomeBack}</h1>
          <p className="text-gray-600">{t.dashboard.readyForAdventure}</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatCard icon={<MapPin className="w-6 h-6" />} label={t.dashboard.totalTrips} value="12" color="blue" />
          <StatCard icon={<Calendar className="w-6 h-6" />} label={t.dashboard.upcoming} value="3" color="green" />
          <StatCard icon={<DollarSign className="w-6 h-6" />} label={t.dashboard.totalBudget} value="$8,400" color="purple" />
          <StatCard icon={<TrendingUp className="w-6 h-6" />} label={t.dashboard.countriesVisited} value="18" color="orange" />
        </div>

        {/* Create New Trip Button */}
        <button
          onClick={() => navigate("/create-trip")}
          className="w-full md:w-auto mb-8 bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5" />
          {t.dashboard.planNewTrip}
        </button>

        {/* Recent Trips */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">{t.dashboard.recentTrips}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {recentTrips.map((trip) => (
              <div
                key={trip.id}
                onClick={() => navigate(`/trip/${trip.id}`)}
                className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
              >
                <img src={trip.image} alt={trip.name} className="w-full h-48 object-cover" />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{trip.name}</h3>
                  <p className="text-gray-600 mb-3">{trip.destinations}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {trip.dates}
                    </span>
                    <span className="flex items-center gap-1">
                      <DollarSign className="w-4 h-4" />
                      {trip.budget}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Recommended Destinations */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">{t.dashboard.recommendedDestinations}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {recommendedDestinations.map((dest) => (
              <div key={dest.name} className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-shadow">
                <img src={dest.image} alt={dest.name} className="w-full h-40 object-cover" />
                <div className="p-4">
                  <h3 className="font-bold text-gray-900">{dest.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: string; color: string }) {
  const colorClasses = {
    blue: "bg-blue-100 text-blue-600",
    green: "bg-green-100 text-green-600",
    purple: "bg-purple-100 text-purple-600",
    orange: "bg-orange-100 text-orange-600"
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className={`inline-flex p-3 rounded-lg ${colorClasses[color as keyof typeof colorClasses]} mb-4`}>
        {icon}
      </div>
      <p className="text-gray-600 text-sm mb-1">{label}</p>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  );
}
