import { Outlet, useLocation, Link } from "react-router";
import { Plane, Map, Calendar, Wallet, Package, User, Home } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { LanguageSwitcher } from "../components/LanguageSwitcher";

export function Root() {
  const location = useLocation();
  const { t } = useLanguage();
  const isAuthPage = location.pathname === "/" || location.pathname === "/signup";

  if (isAuthPage) {
    return <Outlet />;
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <Plane className="w-8 h-8 text-blue-600" />
            <h1 className="font-bold text-xl text-gray-900">Traveloop</h1>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          <NavLink to="/dashboard" icon={<Home className="w-5 h-5" />} label={t.nav.dashboard} />
          <NavLink to="/my-trips" icon={<Map className="w-5 h-5" />} label={t.nav.myTrips} />
          <NavLink to="/cities" icon={<Calendar className="w-5 h-5" />} label={t.nav.exploreCities} />
          <NavLink to="/activities" icon={<Wallet className="w-5 h-5" />} label={t.nav.activities} />
          <NavLink to="/profile" icon={<User className="w-5 h-5" />} label={t.nav.profile} />
        </nav>

        <div className="p-4 border-t border-gray-200">
          <LanguageSwitcher />
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}

function NavLink({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  const location = useLocation();
  const isActive = location.pathname === to || location.pathname.startsWith(to + "/");

  return (
    <Link
      to={to}
      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
        isActive
          ? "bg-blue-50 text-blue-700"
          : "text-gray-700 hover:bg-gray-100"
      }`}
    >
      {icon}
      <span>{label}</span>
    </Link>
  );
}
