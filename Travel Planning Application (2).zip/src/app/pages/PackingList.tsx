import { useState } from "react";
import { useParams, useNavigate } from "react-router";
import { Plus, ArrowLeft, Trash2 } from "lucide-react";

interface PackingItem {
  id: string;
  name: string;
  category: string;
  packed: boolean;
}

export function PackingList() {
  const { tripId } = useParams();
  const navigate = useNavigate();

  const [items, setItems] = useState<PackingItem[]>([
    { id: "1", name: "Passport", category: "Documents", packed: true },
    { id: "2", name: "Flight tickets", category: "Documents", packed: true },
    { id: "3", name: "Travel insurance", category: "Documents", packed: false },
    { id: "4", name: "T-shirts (5)", category: "Clothes", packed: true },
    { id: "5", name: "Jeans (2)", category: "Clothes", packed: false },
    { id: "6", name: "Jacket", category: "Clothes", packed: false },
    { id: "7", name: "Underwear", category: "Clothes", packed: true },
    { id: "8", name: "Shoes (2 pairs)", category: "Clothes", packed: false },
    { id: "9", name: "Phone charger", category: "Electronics", packed: true },
    { id: "10", name: "Laptop", category: "Electronics", packed: false },
    { id: "11", name: "Camera", category: "Electronics", packed: false },
    { id: "12", name: "Power bank", category: "Electronics", packed: true },
    { id: "13", name: "Toothbrush", category: "Toiletries", packed: false },
    { id: "14", name: "Toothpaste", category: "Toiletries", packed: false },
    { id: "15", name: "Shampoo", category: "Toiletries", packed: true }
  ]);

  const [newItemName, setNewItemName] = useState("");
  const [newItemCategory, setNewItemCategory] = useState("Clothes");
  const [showAddItem, setShowAddItem] = useState(false);

  const categories = ["Documents", "Clothes", "Electronics", "Toiletries", "Other"];

  const togglePacked = (id: string) => {
    setItems(items.map(item =>
      item.id === id ? { ...item, packed: !item.packed } : item
    ));
  };

  const deleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const addItem = () => {
    if (newItemName.trim()) {
      setItems([
        ...items,
        {
          id: Date.now().toString(),
          name: newItemName,
          category: newItemCategory,
          packed: false
        }
      ]);
      setNewItemName("");
      setShowAddItem(false);
    }
  };

  const packedCount = items.filter(item => item.packed).length;
  const progressPercentage = (packedCount / items.length) * 100;

  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate(`/trip/${tripId}`)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-gray-600" />
          </button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Packing List</h1>
            <p className="text-gray-600">Keep track of what to bring</p>
          </div>
          <button
            onClick={() => setShowAddItem(true)}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Item
          </button>
        </div>

        {/* Progress */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <span className="font-bold text-gray-900">Packing Progress</span>
            <span className="font-bold text-blue-600">{packedCount} / {items.length}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-4">
            <div
              className="bg-blue-600 h-4 rounded-full transition-all duration-300"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
        </div>

        {/* Items by Category */}
        {categories.map(category => {
          const categoryItems = items.filter(item => item.category === category);
          if (categoryItems.length === 0) return null;

          return (
            <div key={category} className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">{category}</h2>
              <div className="space-y-2">
                {categoryItems.map(item => (
                  <div
                    key={item.id}
                    className="flex items-center gap-4 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <input
                      type="checkbox"
                      checked={item.packed}
                      onChange={() => togglePacked(item.id)}
                      className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-2 focus:ring-blue-500"
                    />
                    <span className={`flex-1 ${item.packed ? "line-through text-gray-500" : "text-gray-900"}`}>
                      {item.name}
                    </span>
                    <button
                      onClick={() => deleteItem(item.id)}
                      className="p-2 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-5 h-5 text-red-600" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Add Item Modal */}
        {showAddItem && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Add Item</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Item Name</label>
                  <input
                    type="text"
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                    placeholder="e.g., Sunglasses"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                  <select
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    setShowAddItem(false);
                    setNewItemName("");
                  }}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={addItem}
                  className="flex-1 bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Add Item
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
