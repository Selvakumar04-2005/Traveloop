import { useParams, useNavigate } from "react-router";
import { Calendar, MapPin, DollarSign, Package, Edit, Share2, List } from "lucide-react";

export function TripDetails() {
  const { tripId } = useParams();
  const navigate = useNavigate();

  // Mock trip data
  const trip = {
    id: tripId,
    name: "European Adventure",
    description: "Exploring the culture and history of Europe",
    startDate: "Jun 15, 2026",
    endDate: "Jun 30, 2026",
    image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1200&h=400&fit=crop",
    destinations: ["Paris, France", "Rome, Italy", "Barcelona, Spain"],
    totalBudget: "$3,500",
    activities: 12
  };

  return (
    <div>
      {/* Hero Section */}
      <div className="relative h-80">
        <img src={trip.image} alt={trip.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-4xl font-bold mb-2">{trip.name}</h1>
            <p className="text-lg opacity-90">{trip.description}</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <ActionButton
              icon={<List className="w-5 h-5" />}
              label="View Itinerary"
              onClick={() => navigate(`/trip/${tripId}/itinerary`)}
            />
            <ActionButton
              icon={<DollarSign className="w-5 h-5" />}
              label="Budget"
              onClick={() => navigate(`/trip/${tripId}/budget`)}
            />
            <ActionButton
              icon={<Package className="w-5 h-5" />}
              label="Packing List"
              onClick={() => navigate(`/trip/${tripId}/packing`)}
            />
            <ActionButton
              icon={<Share2 className="w-5 h-5" />}
              label="Share Trip"
              onClick={() => alert("Share functionality coming soon!")}
            />
          </div>

          {/* Trip Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <InfoCard
              icon={<Calendar className="w-6 h-6 text-blue-600" />}
              label="Duration"
              value={`${trip.startDate} - ${trip.endDate}`}
            />
            <InfoCard
              icon={<MapPin className="w-6 h-6 text-green-600" />}
              label="Destinations"
              value={`${trip.destinations.length} cities`}
            />
            <InfoCard
              icon={<DollarSign className="w-6 h-6 text-purple-600" />}
              label="Total Budget"
              value={trip.totalBudget}
            />
          </div>

          {/* Destinations */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Trip Route</h2>
              <button
                onClick={() => navigate(`/trip/${tripId}/itinerary`)}
                className="text-blue-600 hover:underline flex items-center gap-1"
              >
                <Edit className="w-4 h-4" />
                Edit Itinerary
              </button>
            </div>
            <div className="space-y-4">
              {trip.destinations.map((destination, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className="bg-blue-100 text-blue-600 w-10 h-10 rounded-full flex items-center justify-center font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-900">{destination}</h3>
                    <p className="text-sm text-gray-600">Day {index + 1} - Day {index + 3}</p>
                  </div>
                  <MapPin className="w-5 h-5 text-gray-400" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ActionButton({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="bg-white border border-gray-300 rounded-lg p-4 hover:bg-gray-50 transition-colors flex items-center gap-3"
    >
      {icon}
      <span className="font-medium text-gray-900">{label}</span>
    </button>
  );
}

function InfoCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center gap-3 mb-2">
        {icon}
        <span className="text-sm text-gray-600">{label}</span>
      </div>
      <p className="text-xl font-bold text-gray-900">{value}</p>
    </div>
  );
}
