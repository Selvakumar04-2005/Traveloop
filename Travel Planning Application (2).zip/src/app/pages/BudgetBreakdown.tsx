import { useParams, useNavigate } from "react-router";
import { DollarSign, TrendingUp, PieChart, ArrowLeft } from "lucide-react";
import { PieChart as RechartsPie, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

export function BudgetBreakdown() {
  const { tripId } = useParams();
  const navigate = useNavigate();

  const budgetData = [
    { name: "Transportation", value: 800, color: "#3b82f6" },
    { name: "Accommodation", value: 1200, color: "#8b5cf6" },
    { name: "Food & Dining", value: 900, color: "#10b981" },
    { name: "Activities", value: 600, color: "#f59e0b" }
  ];

  const totalBudget = budgetData.reduce((sum, item) => sum + item.value, 0);

  const expenses = [
    { category: "Transportation", item: "Flight tickets", amount: 500, date: "2026-06-01" },
    { category: "Transportation", item: "Train passes", amount: 200, date: "2026-06-05" },
    { category: "Transportation", item: "Local transport", amount: 100, date: "2026-06-10" },
    { category: "Accommodation", item: "Hotel Paris", amount: 400, date: "2026-06-15" },
    { category: "Accommodation", item: "Hotel Rome", amount: 500, date: "2026-06-20" },
    { category: "Accommodation", item: "Hotel Barcelona", amount: 300, date: "2026-06-25" },
    { category: "Food & Dining", item: "Restaurants", amount: 600, date: "Various" },
    { category: "Food & Dining", item: "Groceries", amount: 200, date: "Various" },
    { category: "Food & Dining", item: "Cafes", amount: 100, date: "Various" },
    { category: "Activities", item: "Museum tickets", amount: 200, date: "2026-06-16" },
    { category: "Activities", item: "Tours", amount: 300, date: "2026-06-22" },
    { category: "Activities", item: "Entertainment", amount: 100, date: "2026-06-28" }
  ];

  return (
    <div className="p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate(`/trip/${tripId}`)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-gray-600" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Budget Breakdown</h1>
            <p className="text-gray-600">Track and manage your trip expenses</p>
          </div>
        </div>

        {/* Total Budget */}
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg p-8 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 mb-2">Total Trip Budget</p>
              <h2 className="text-5xl font-bold">${totalBudget.toLocaleString()}</h2>
            </div>
            <div className="bg-white/20 p-4 rounded-full">
              <DollarSign className="w-12 h-12" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Pie Chart */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Expense Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <RechartsPie>
                <Pie
                  data={budgetData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {budgetData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </RechartsPie>
            </ResponsiveContainer>
          </div>

          {/* Category Summary */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Category Summary</h3>
            <div className="space-y-4">
              {budgetData.map((item) => (
                <div key={item.name}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-gray-900">{item.name}</span>
                    <span className="font-bold text-gray-900">${item.value}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full"
                      style={{
                        width: `${(item.value / totalBudget) * 100}%`,
                        backgroundColor: item.color
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Detailed Expenses */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Detailed Expenses</h3>
          <div className="space-y-3">
            {expenses.map((expense, index) => (
              <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center"
                    style={{
                      backgroundColor: budgetData.find(b => b.name === expense.category)?.color + "20"
                    }}
                  >
                    <DollarSign
                      className="w-6 h-6"
                      style={{
                        color: budgetData.find(b => b.name === expense.category)?.color
                      }}
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">{expense.item}</h4>
                    <p className="text-sm text-gray-600">{expense.category} • {expense.date}</p>
                  </div>
                </div>
                <div className="font-bold text-lg text-gray-900">${expense.amount}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
