import { useState } from "react";
import { Search, Clock, DollarSign, Tag, Plus } from "lucide-react";

interface Activity {
  id: string;
  name: string;
  type: string;
  duration: string;
  cost: number;
  city: string;
  description: string;
  image: string;
}

export function ActivitySearch() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("All");
  const [maxCost, setMaxCost] = useState(1000);

  const activities: Activity[] = [
    {
      id: "1",
      name: "Eiffel Tower Visit",
      type: "Sightseeing",
      duration: "3 hours",
      cost: 30,
      city: "Paris",
      description: "Iconic landmark with breathtaking views of Paris",
      image: "https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?w=600&h=400&fit=crop"
    },
    {
      id: "2",
      name: "Louvre Museum Tour",
      type: "Museum",
      duration: "4 hours",
      cost: 45,
      city: "Paris",
      description: "World's largest art museum with incredible masterpieces",
      image: "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"
    },
    {
      id: "3",
      name: "Seine River Cruise",
      type: "Boat Tour",
      duration: "2 hours",
      cost: 50,
      city: "Paris",
      description: "Romantic boat tour along the Seine River",
      image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600&h=400&fit=crop"
    },
    {
      id: "4",
      name: "Colosseum Tour",
      type: "Sightseeing",
      duration: "2 hours",
      cost: 25,
      city: "Rome",
      description: "Ancient Roman amphitheater and iconic landmark",
      image: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=600&h=400&fit=crop"
    },
    {
      id: "5",
      name: "Vatican Museums",
      type: "Museum",
      duration: "3 hours",
      cost: 35,
      city: "Rome",
      description: "Incredible art collection and Sistine Chapel",
      image: "https://images.unsplash.com/photo-1531572753322-ad063cecc140?w=600&h=400&fit=crop"
    },
    {
      id: "6",
      name: "Pizza Making Class",
      type: "Food Tour",
      duration: "2.5 hours",
      cost: 75,
      city: "Rome",
      description: "Learn to make authentic Italian pizza",
      image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&h=400&fit=crop"
    },
    {
      id: "7",
      name: "Sagrada Familia Visit",
      type: "Sightseeing",
      duration: "2 hours",
      cost: 33,
      city: "Barcelona",
      description: "Gaudi's masterpiece basilica",
      image: "https://images.unsplash.com/photo-1523531294919-4bcd7c65e216?w=600&h=400&fit=crop"
    },
    {
      id: "8",
      name: "Beach Volleyball",
      type: "Adventure",
      duration: "1.5 hours",
      cost: 20,
      city: "Barcelona",
      description: "Fun beach sports at Barceloneta",
      image: "https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?w=600&h=400&fit=crop"
    }
  ];

  const activityTypes = ["All", "Sightseeing", "Museum", "Food Tour", "Adventure", "Boat Tour"];

  const filteredActivities = activities.filter(activity => {
    const matchesSearch = activity.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         activity.city.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === "All" || activity.type === selectedType;
    const matchesCost = activity.cost <= maxCost;
    return matchesSearch && matchesType && matchesCost;
  });

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Discover Activities</h1>
          <p className="text-gray-600">Find exciting things to do on your trip</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search activities..."
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Activity Type</label>
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {activityTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Max Cost: ${maxCost}
                </label>
                <input
                  type="range"
                  min="0"
                  max="200"
                  step="10"
                  value={maxCost}
                  onChange={(e) => setMaxCost(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Activities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredActivities.map(activity => (
            <div key={activity.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <img src={activity.image} alt={activity.name} className="w-full h-48 object-cover" />
              <div className="p-6">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-xl font-bold text-gray-900">{activity.name}</h3>
                  <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-medium">
                    {activity.type}
                  </span>
                </div>
                <p className="text-gray-600 text-sm mb-4">{activity.description}</p>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span>{activity.duration}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <DollarSign className="w-4 h-4" />
                    <span>${activity.cost} per person</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Tag className="w-4 h-4" />
                    <span>{activity.city}</span>
                  </div>
                </div>

                <button className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2">
                  <Plus className="w-4 h-4" />
                  Add to Itinerary
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredActivities.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No activities found matching your criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}
