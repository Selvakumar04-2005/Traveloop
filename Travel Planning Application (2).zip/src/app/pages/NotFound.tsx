import { useNavigate } from "react-router";
import { Home, MapPin } from "lucide-react";

export function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center p-4">
      <div className="text-center text-white">
        <MapPin className="w-24 h-24 mx-auto mb-6 opacity-80" />
        <h1 className="text-6xl font-bold mb-4">404</h1>
        <h2 className="text-3xl font-bold mb-4">Page Not Found</h2>
        <p className="text-xl mb-8 opacity-90">
          Looks like you've wandered off the map!
        </p>
        <button
          onClick={() => navigate("/dashboard")}
          className="bg-white text-blue-600 px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors inline-flex items-center gap-2 font-bold"
        >
          <Home className="w-5 h-5" />
          Back to Dashboard
        </button>
      </div>
    </div>
  );
}
