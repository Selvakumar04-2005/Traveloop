import { createBrowserRouter } from "react-router";
import { Root } from "./pages/Root";
import { Dashboard } from "./pages/Dashboard";
import { Login } from "./pages/Login";
import { Signup } from "./pages/Signup";
import { MyTrips } from "./pages/MyTrips";
import { CreateTrip } from "./pages/CreateTrip";
import { TripDetails } from "./pages/TripDetails";
import { ItineraryBuilder } from "./pages/ItineraryBuilder";
import { CitySearch } from "./pages/CitySearch";
import { ActivitySearch } from "./pages/ActivitySearch";
import { BudgetBreakdown } from "./pages/BudgetBreakdown";
import { PackingList } from "./pages/PackingList";
import { UserProfile } from "./pages/UserProfile";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Login },
      { path: "signup", Component: Signup },
      { path: "dashboard", Component: Dashboard },
      { path: "my-trips", Component: MyTrips },
      { path: "create-trip", Component: CreateTrip },
      { path: "trip/:tripId", Component: TripDetails },
      { path: "trip/:tripId/itinerary", Component: ItineraryBuilder },
      { path: "trip/:tripId/budget", Component: BudgetBreakdown },
      { path: "trip/:tripId/packing", Component: PackingList },
      { path: "cities", Component: CitySearch },
      { path: "activities", Component: ActivitySearch },
      { path: "profile", Component: UserProfile },
      { path: "*", Component: NotFound },
    ],
  },
]);
