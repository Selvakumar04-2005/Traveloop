export const translations = {
  en: {
    // Common
    common: {
      save: "Save",
      cancel: "Cancel",
      edit: "Edit",
      delete: "Delete",
      add: "Add",
      search: "Search",
      loading: "Loading...",
      back: "Back",
    },

    // Navigation
    nav: {
      dashboard: "Dashboard",
      myTrips: "My Trips",
      exploreCities: "Explore Cities",
      activities: "Activities",
      profile: "Profile",
    },

    // Auth
    auth: {
      login: "Sign In",
      signup: "Sign Up",
      logout: "Logout",
      email: "Email",
      password: "Password",
      confirmPassword: "Confirm Password",
      fullName: "Full Name",
      dontHaveAccount: "Don't have an account?",
      alreadyHaveAccount: "Already have an account?",
      planDreamJourney: "Plan your dream journey",
      startPlanningTrips: "Start planning amazing trips",
    },

    // Dashboard
    dashboard: {
      welcomeBack: "Welcome back, Traveler!",
      readyForAdventure: "Ready to plan your next adventure?",
      totalTrips: "Total Trips",
      upcoming: "Upcoming",
      totalBudget: "Total Budget",
      countriesVisited: "Countries Visited",
      planNewTrip: "Plan New Trip",
      recentTrips: "Recent Trips",
      recommendedDestinations: "Recommended Destinations",
    },

    // My Trips
    myTrips: {
      title: "My Trips",
      subtitle: "Manage and view all your travel plans",
      createNewTrip: "Create New Trip",
      destinations: "destinations",
      viewTrip: "View Trip",
    },

    // Create Trip
    createTrip: {
      title: "Create New Trip",
      subtitle: "Start planning your next adventure",
      tripName: "Trip Name",
      description: "Description",
      startDate: "Start Date",
      endDate: "End Date",
      coverImage: "Cover Image URL (optional)",
      createAndAddDestinations: "Create Trip & Add Destinations",
      tripNamePlaceholder: "e.g., European Adventure",
      descriptionPlaceholder: "Describe your trip...",
    },

    // Trip Details
    tripDetails: {
      viewItinerary: "View Itinerary",
      budget: "Budget",
      packingList: "Packing List",
      shareTrip: "Share Trip",
      duration: "Duration",
      totalBudget: "Total Budget",
      tripRoute: "Trip Route",
      editItinerary: "Edit Itinerary",
      day: "Day",
    },

    // Itinerary
    itinerary: {
      title: "Itinerary Builder",
      subtitle: "Plan your route and activities",
      backToTrip: "Back to Trip",
      addStop: "Add Stop",
      activities: "Activities",
      addActivity: "Add Activity",
      addNewStop: "Add New Stop",
      cityName: "City name",
      country: "Country",
    },

    // Budget
    budget: {
      title: "Budget Breakdown",
      subtitle: "Track and manage your trip expenses",
      totalTripBudget: "Total Trip Budget",
      expenseDistribution: "Expense Distribution",
      categorySummary: "Category Summary",
      detailedExpenses: "Detailed Expenses",
      transportation: "Transportation",
      accommodation: "Accommodation",
      foodDining: "Food & Dining",
      activities: "Activities",
    },

    // Packing List
    packing: {
      title: "Packing List",
      subtitle: "Keep track of what to bring",
      addItem: "Add Item",
      packingProgress: "Packing Progress",
      itemName: "Item Name",
      category: "Category",
      documents: "Documents",
      clothes: "Clothes",
      electronics: "Electronics",
      toiletries: "Toiletries",
      other: "Other",
    },

    // City Search
    cities: {
      title: "Explore Cities",
      subtitle: "Discover amazing destinations around the world",
      searchPlaceholder: "Search cities or countries...",
      addToTrip: "Add to Trip",
      noCitiesFound: "No cities found matching your search",
    },

    // Activity Search
    activities: {
      title: "Discover Activities",
      subtitle: "Find exciting things to do on your trip",
      searchPlaceholder: "Search activities...",
      activityType: "Activity Type",
      maxCost: "Max Cost",
      perPerson: "per person",
      addToItinerary: "Add to Itinerary",
      noActivitiesFound: "No activities found matching your criteria",
    },

    // Profile
    profile: {
      title: "My Profile",
      subtitle: "Manage your account settings and preferences",
      fullName: "Full Name",
      email: "Email",
      location: "Location",
      bio: "Bio",
      saveChanges: "Save Changes",
      tripsPlanned: "Trips Planned",
      countriesVisited: "Countries Visited",
      citiesExplored: "Cities Explored",
      totalBudgetManaged: "Total Budget Managed",
      savedDestinations: "Saved Destinations",
      language: "Language",
    },

    // 404
    notFound: {
      title: "Page Not Found",
      message: "Looks like you've wandered off the map!",
      backToDashboard: "Back to Dashboard",
    },
  },

  es: {
    // Common
    common: {
      save: "Guardar",
      cancel: "Cancelar",
      edit: "Editar",
      delete: "Eliminar",
      add: "Agregar",
      search: "Buscar",
      loading: "Cargando...",
      back: "Volver",
    },

    // Navigation
    nav: {
      dashboard: "Panel",
      myTrips: "Mis Viajes",
      exploreCities: "Explorar Ciudades",
      activities: "Actividades",
      profile: "Perfil",
    },

    // Auth
    auth: {
      login: "Iniciar Sesión",
      signup: "Registrarse",
      logout: "Cerrar Sesión",
      email: "Correo Electrónico",
      password: "Contraseña",
      confirmPassword: "Confirmar Contraseña",
      fullName: "Nombre Completo",
      dontHaveAccount: "¿No tienes una cuenta?",
      alreadyHaveAccount: "¿Ya tienes una cuenta?",
      planDreamJourney: "Planifica el viaje de tus sueños",
      startPlanningTrips: "Comienza a planificar viajes increíbles",
    },

    // Dashboard
    dashboard: {
      welcomeBack: "¡Bienvenido de nuevo, Viajero!",
      readyForAdventure: "¿Listo para planificar tu próxima aventura?",
      totalTrips: "Viajes Totales",
      upcoming: "Próximos",
      totalBudget: "Presupuesto Total",
      countriesVisited: "Países Visitados",
      planNewTrip: "Planificar Nuevo Viaje",
      recentTrips: "Viajes Recientes",
      recommendedDestinations: "Destinos Recomendados",
    },

    // My Trips
    myTrips: {
      title: "Mis Viajes",
      subtitle: "Gestiona y visualiza todos tus planes de viaje",
      createNewTrip: "Crear Nuevo Viaje",
      destinations: "destinos",
      viewTrip: "Ver Viaje",
    },

    // Create Trip
    createTrip: {
      title: "Crear Nuevo Viaje",
      subtitle: "Comienza a planificar tu próxima aventura",
      tripName: "Nombre del Viaje",
      description: "Descripción",
      startDate: "Fecha de Inicio",
      endDate: "Fecha de Fin",
      coverImage: "URL de Imagen de Portada (opcional)",
      createAndAddDestinations: "Crear Viaje y Agregar Destinos",
      tripNamePlaceholder: "ej., Aventura Europea",
      descriptionPlaceholder: "Describe tu viaje...",
    },

    // Trip Details
    tripDetails: {
      viewItinerary: "Ver Itinerario",
      budget: "Presupuesto",
      packingList: "Lista de Equipaje",
      shareTrip: "Compartir Viaje",
      duration: "Duración",
      totalBudget: "Presupuesto Total",
      tripRoute: "Ruta del Viaje",
      editItinerary: "Editar Itinerario",
      day: "Día",
    },

    // Itinerary
    itinerary: {
      title: "Constructor de Itinerario",
      subtitle: "Planifica tu ruta y actividades",
      backToTrip: "Volver al Viaje",
      addStop: "Agregar Parada",
      activities: "Actividades",
      addActivity: "Agregar Actividad",
      addNewStop: "Agregar Nueva Parada",
      cityName: "Nombre de la ciudad",
      country: "País",
    },

    // Budget
    budget: {
      title: "Desglose de Presupuesto",
      subtitle: "Rastrea y gestiona tus gastos de viaje",
      totalTripBudget: "Presupuesto Total del Viaje",
      expenseDistribution: "Distribución de Gastos",
      categorySummary: "Resumen por Categoría",
      detailedExpenses: "Gastos Detallados",
      transportation: "Transporte",
      accommodation: "Alojamiento",
      foodDining: "Comida y Restaurantes",
      activities: "Actividades",
    },

    // Packing List
    packing: {
      title: "Lista de Equipaje",
      subtitle: "Mantén un registro de lo que llevar",
      addItem: "Agregar Artículo",
      packingProgress: "Progreso de Equipaje",
      itemName: "Nombre del Artículo",
      category: "Categoría",
      documents: "Documentos",
      clothes: "Ropa",
      electronics: "Electrónicos",
      toiletries: "Artículos de Aseo",
      other: "Otro",
    },

    // City Search
    cities: {
      title: "Explorar Ciudades",
      subtitle: "Descubre destinos increíbles alrededor del mundo",
      searchPlaceholder: "Buscar ciudades o países...",
      addToTrip: "Agregar al Viaje",
      noCitiesFound: "No se encontraron ciudades que coincidan con tu búsqueda",
    },

    // Activity Search
    activities: {
      title: "Descubrir Actividades",
      subtitle: "Encuentra cosas emocionantes para hacer en tu viaje",
      searchPlaceholder: "Buscar actividades...",
      activityType: "Tipo de Actividad",
      maxCost: "Costo Máximo",
      perPerson: "por persona",
      addToItinerary: "Agregar al Itinerario",
      noActivitiesFound: "No se encontraron actividades que coincidan con tus criterios",
    },

    // Profile
    profile: {
      title: "Mi Perfil",
      subtitle: "Gestiona la configuración de tu cuenta y preferencias",
      fullName: "Nombre Completo",
      email: "Correo Electrónico",
      location: "Ubicación",
      bio: "Biografía",
      saveChanges: "Guardar Cambios",
      tripsPlanned: "Viajes Planificados",
      countriesVisited: "Países Visitados",
      citiesExplored: "Ciudades Exploradas",
      totalBudgetManaged: "Presupuesto Total Gestionado",
      savedDestinations: "Destinos Guardados",
      language: "Idioma",
    },

    // 404
    notFound: {
      title: "Página No Encontrada",
      message: "¡Parece que te has desviado del mapa!",
      backToDashboard: "Volver al Panel",
    },
  },

  fr: {
    // Common
    common: {
      save: "Enregistrer",
      cancel: "Annuler",
      edit: "Modifier",
      delete: "Supprimer",
      add: "Ajouter",
      search: "Rechercher",
      loading: "Chargement...",
      back: "Retour",
    },

    // Navigation
    nav: {
      dashboard: "Tableau de Bord",
      myTrips: "Mes Voyages",
      exploreCities: "Explorer les Villes",
      activities: "Activités",
      profile: "Profil",
    },

    // Auth
    auth: {
      login: "Se Connecter",
      signup: "S'inscrire",
      logout: "Déconnexion",
      email: "Email",
      password: "Mot de Passe",
      confirmPassword: "Confirmer le Mot de Passe",
      fullName: "Nom Complet",
      dontHaveAccount: "Vous n'avez pas de compte?",
      alreadyHaveAccount: "Vous avez déjà un compte?",
      planDreamJourney: "Planifiez le voyage de vos rêves",
      startPlanningTrips: "Commencez à planifier des voyages incroyables",
    },

    // Dashboard
    dashboard: {
      welcomeBack: "Bon retour, Voyageur!",
      readyForAdventure: "Prêt à planifier votre prochaine aventure?",
      totalTrips: "Voyages Totaux",
      upcoming: "À Venir",
      totalBudget: "Budget Total",
      countriesVisited: "Pays Visités",
      planNewTrip: "Planifier un Nouveau Voyage",
      recentTrips: "Voyages Récents",
      recommendedDestinations: "Destinations Recommandées",
    },

    // My Trips
    myTrips: {
      title: "Mes Voyages",
      subtitle: "Gérez et visualisez tous vos plans de voyage",
      createNewTrip: "Créer un Nouveau Voyage",
      destinations: "destinations",
      viewTrip: "Voir le Voyage",
    },

    // Create Trip
    createTrip: {
      title: "Créer un Nouveau Voyage",
      subtitle: "Commencez à planifier votre prochaine aventure",
      tripName: "Nom du Voyage",
      description: "Description",
      startDate: "Date de Début",
      endDate: "Date de Fin",
      coverImage: "URL de l'Image de Couverture (optionnel)",
      createAndAddDestinations: "Créer un Voyage et Ajouter des Destinations",
      tripNamePlaceholder: "par ex., Aventure Européenne",
      descriptionPlaceholder: "Décrivez votre voyage...",
    },

    // Trip Details
    tripDetails: {
      viewItinerary: "Voir l'Itinéraire",
      budget: "Budget",
      packingList: "Liste de Bagages",
      shareTrip: "Partager le Voyage",
      duration: "Durée",
      totalBudget: "Budget Total",
      tripRoute: "Itinéraire du Voyage",
      editItinerary: "Modifier l'Itinéraire",
      day: "Jour",
    },

    // Itinerary
    itinerary: {
      title: "Constructeur d'Itinéraire",
      subtitle: "Planifiez votre itinéraire et vos activités",
      backToTrip: "Retour au Voyage",
      addStop: "Ajouter une Étape",
      activities: "Activités",
      addActivity: "Ajouter une Activité",
      addNewStop: "Ajouter une Nouvelle Étape",
      cityName: "Nom de la ville",
      country: "Pays",
    },

    // Budget
    budget: {
      title: "Répartition du Budget",
      subtitle: "Suivez et gérez vos dépenses de voyage",
      totalTripBudget: "Budget Total du Voyage",
      expenseDistribution: "Répartition des Dépenses",
      categorySummary: "Résumé par Catégorie",
      detailedExpenses: "Dépenses Détaillées",
      transportation: "Transport",
      accommodation: "Hébergement",
      foodDining: "Nourriture et Restaurants",
      activities: "Activités",
    },

    // Packing List
    packing: {
      title: "Liste de Bagages",
      subtitle: "Gardez une trace de ce qu'il faut apporter",
      addItem: "Ajouter un Article",
      packingProgress: "Progression des Bagages",
      itemName: "Nom de l'Article",
      category: "Catégorie",
      documents: "Documents",
      clothes: "Vêtements",
      electronics: "Électronique",
      toiletries: "Articles de Toilette",
      other: "Autre",
    },

    // City Search
    cities: {
      title: "Explorer les Villes",
      subtitle: "Découvrez des destinations incroyables dans le monde entier",
      searchPlaceholder: "Rechercher des villes ou des pays...",
      addToTrip: "Ajouter au Voyage",
      noCitiesFound: "Aucune ville trouvée correspondant à votre recherche",
    },

    // Activity Search
    activities: {
      title: "Découvrir des Activités",
      subtitle: "Trouvez des choses passionnantes à faire lors de votre voyage",
      searchPlaceholder: "Rechercher des activités...",
      activityType: "Type d'Activité",
      maxCost: "Coût Maximum",
      perPerson: "par personne",
      addToItinerary: "Ajouter à l'Itinéraire",
      noActivitiesFound: "Aucune activité trouvée correspondant à vos critères",
    },

    // Profile
    profile: {
      title: "Mon Profil",
      subtitle: "Gérez les paramètres de votre compte et vos préférences",
      fullName: "Nom Complet",
      email: "Email",
      location: "Emplacement",
      bio: "Biographie",
      saveChanges: "Enregistrer les Modifications",
      tripsPlanned: "Voyages Planifiés",
      countriesVisited: "Pays Visités",
      citiesExplored: "Villes Explorées",
      totalBudgetManaged: "Budget Total Géré",
      savedDestinations: "Destinations Enregistrées",
      language: "Langue",
    },

    // 404
    notFound: {
      title: "Page Non Trouvée",
      message: "On dirait que vous vous êtes égaré de la carte!",
      backToDashboard: "Retour au Tableau de Bord",
    },
  },

  de: {
    // Common
    common: {
      save: "Speichern",
      cancel: "Abbrechen",
      edit: "Bearbeiten",
      delete: "Löschen",
      add: "Hinzufügen",
      search: "Suchen",
      loading: "Laden...",
      back: "Zurück",
    },

    // Navigation
    nav: {
      dashboard: "Dashboard",
      myTrips: "Meine Reisen",
      exploreCities: "Städte Erkunden",
      activities: "Aktivitäten",
      profile: "Profil",
    },

    // Auth
    auth: {
      login: "Anmelden",
      signup: "Registrieren",
      logout: "Abmelden",
      email: "E-Mail",
      password: "Passwort",
      confirmPassword: "Passwort Bestätigen",
      fullName: "Vollständiger Name",
      dontHaveAccount: "Kein Konto?",
      alreadyHaveAccount: "Bereits ein Konto?",
      planDreamJourney: "Planen Sie Ihre Traumreise",
      startPlanningTrips: "Beginnen Sie mit der Planung erstaunlicher Reisen",
    },

    // Dashboard
    dashboard: {
      welcomeBack: "Willkommen zurück, Reisender!",
      readyForAdventure: "Bereit für Ihr nächstes Abenteuer?",
      totalTrips: "Gesamte Reisen",
      upcoming: "Bevorstehend",
      totalBudget: "Gesamtbudget",
      countriesVisited: "Besuchte Länder",
      planNewTrip: "Neue Reise Planen",
      recentTrips: "Letzte Reisen",
      recommendedDestinations: "Empfohlene Ziele",
    },

    // My Trips
    myTrips: {
      title: "Meine Reisen",
      subtitle: "Verwalten und anzeigen Sie alle Ihre Reisepläne",
      createNewTrip: "Neue Reise Erstellen",
      destinations: "Ziele",
      viewTrip: "Reise Ansehen",
    },

    // Create Trip
    createTrip: {
      title: "Neue Reise Erstellen",
      subtitle: "Beginnen Sie mit der Planung Ihres nächsten Abenteuers",
      tripName: "Reisename",
      description: "Beschreibung",
      startDate: "Startdatum",
      endDate: "Enddatum",
      coverImage: "Titelbild-URL (optional)",
      createAndAddDestinations: "Reise Erstellen & Ziele Hinzufügen",
      tripNamePlaceholder: "z.B. Europäisches Abenteuer",
      descriptionPlaceholder: "Beschreiben Sie Ihre Reise...",
    },

    // Trip Details
    tripDetails: {
      viewItinerary: "Reiseroute Ansehen",
      budget: "Budget",
      packingList: "Packliste",
      shareTrip: "Reise Teilen",
      duration: "Dauer",
      totalBudget: "Gesamtbudget",
      tripRoute: "Reiseroute",
      editItinerary: "Reiseroute Bearbeiten",
      day: "Tag",
    },

    // Itinerary
    itinerary: {
      title: "Reiserouten-Builder",
      subtitle: "Planen Sie Ihre Route und Aktivitäten",
      backToTrip: "Zurück zur Reise",
      addStop: "Stopp Hinzufügen",
      activities: "Aktivitäten",
      addActivity: "Aktivität Hinzufügen",
      addNewStop: "Neuen Stopp Hinzufügen",
      cityName: "Stadtname",
      country: "Land",
    },

    // Budget
    budget: {
      title: "Budget-Aufschlüsselung",
      subtitle: "Verfolgen und verwalten Sie Ihre Reisekosten",
      totalTripBudget: "Gesamtreisebudget",
      expenseDistribution: "Ausgabenverteilung",
      categorySummary: "Kategorieübersicht",
      detailedExpenses: "Detaillierte Ausgaben",
      transportation: "Transport",
      accommodation: "Unterkunft",
      foodDining: "Essen & Restaurants",
      activities: "Aktivitäten",
    },

    // Packing List
    packing: {
      title: "Packliste",
      subtitle: "Behalten Sie den Überblick über das Mitzubringende",
      addItem: "Artikel Hinzufügen",
      packingProgress: "Packfortschritt",
      itemName: "Artikelname",
      category: "Kategorie",
      documents: "Dokumente",
      clothes: "Kleidung",
      electronics: "Elektronik",
      toiletries: "Toilettenartikel",
      other: "Andere",
    },

    // City Search
    cities: {
      title: "Städte Erkunden",
      subtitle: "Entdecken Sie erstaunliche Ziele auf der ganzen Welt",
      searchPlaceholder: "Städte oder Länder suchen...",
      addToTrip: "Zur Reise Hinzufügen",
      noCitiesFound: "Keine Städte gefunden, die Ihrer Suche entsprechen",
    },

    // Activity Search
    activities: {
      title: "Aktivitäten Entdecken",
      subtitle: "Finden Sie aufregende Dinge für Ihre Reise",
      searchPlaceholder: "Aktivitäten suchen...",
      activityType: "Aktivitätstyp",
      maxCost: "Maximale Kosten",
      perPerson: "pro Person",
      addToItinerary: "Zur Reiseroute Hinzufügen",
      noActivitiesFound: "Keine Aktivitäten gefunden, die Ihren Kriterien entsprechen",
    },

    // Profile
    profile: {
      title: "Mein Profil",
      subtitle: "Verwalten Sie Ihre Kontoeinstellungen und Präferenzen",
      fullName: "Vollständiger Name",
      email: "E-Mail",
      location: "Standort",
      bio: "Biografie",
      saveChanges: "Änderungen Speichern",
      tripsPlanned: "Geplante Reisen",
      countriesVisited: "Besuchte Länder",
      citiesExplored: "Erkundete Städte",
      totalBudgetManaged: "Verwaltetes Gesamtbudget",
      savedDestinations: "Gespeicherte Ziele",
      language: "Sprache",
    },

    // 404
    notFound: {
      title: "Seite Nicht Gefunden",
      message: "Sieht so aus, als hätten Sie sich von der Karte verirrt!",
      backToDashboard: "Zurück zum Dashboard",
    },
  },
};

export type Language = keyof typeof translations;
export type TranslationKeys = typeof translations.en;
