# Traveloop - Complete Travel Planning Application

## 🌟 Project Overview
Traveloop is a full-stack travel planning application with:
- **Frontend**: React + TypeScript + Tailwind CSS with multi-language support
- **Backend**: Java Spring Boot REST API with H2/PostgreSQL database

---

## 🌐 Multi-Language Support (i18n)

### Supported Languages
- 🇺🇸 **English** (en)
- 🇪🇸 **Spanish** (es)
- 🇫🇷 **French** (fr)
- 🇩🇪 **German** (de)

### How It Works
1. **Language Context**: Uses React Context API to manage language state
2. **Translations**: All text is stored in `/src/app/i18n/translations.ts`
3. **Language Switcher**: Available in the sidebar and login page
4. **Persistence**: Language preference saved to localStorage

### Using Translations in Components
```typescript
import { useLanguage } from "../context/LanguageContext";

function MyComponent() {
  const { t } = useLanguage();
  
  return <h1>{t.dashboard.welcomeBack}</h1>;
}
```

### Adding New Languages
1. Open `/src/app/i18n/translations.ts`
2. Add new language object (e.g., `it` for Italian)
3. Translate all keys from English version
4. Update `LanguageSwitcher.tsx` to include new language

---

## ☕ Java Spring Boot Backend

### Architecture
```
Backend (Spring Boot)
├── Models (JPA Entities)
│   ├── User
│   ├── Trip
│   ├── TripStop
│   ├── Activity
│   ├── Budget
│   └── PackingItem
├── Repositories (Data Access)
├── Services (Business Logic)
├── Controllers (REST APIs)
└── Config (CORS, etc.)
```

### Database Schema
```sql
users
├── id (PK)
├── name
├── email (unique)
├── password
├── location
├── bio
├── language
└── timestamps

trips
├── id (PK)
├── user_id (FK)
├── name
├── description
├── start_date
├── end_date
├── cover_image_url
├── total_budget
├── is_public
└── timestamps

trip_stops
├── id (PK)
├── trip_id (FK)
├── city
├── country
├── start_date
├── end_date
├── stop_order
└── timestamps

activities
├── id (PK)
├── trip_stop_id (FK)
├── name
├── activity_type
├── start_time
├── duration
├── cost
└── timestamps

budgets
├── id (PK)
├── trip_id (FK)
├── category
├── item
├── amount
└── timestamps

packing_items
├── id (PK)
├── trip_id (FK)
├── name
├── category
├── is_packed
└── timestamps
```

### REST API Endpoints

#### User APIs
```
POST   /api/users/register         - Register new user
POST   /api/users/login            - User login
GET    /api/users/{id}             - Get user profile
PUT    /api/users/{id}             - Update user
DELETE /api/users/{id}             - Delete user
```

#### Trip APIs
```
GET    /api/trips                  - Get all trips
GET    /api/trips/{id}             - Get trip by ID
GET    /api/trips/user/{userId}    - Get user's trips
POST   /api/trips/user/{userId}    - Create new trip
PUT    /api/trips/{id}             - Update trip
DELETE /api/trips/{id}             - Delete trip
```

#### Trip Stop APIs
```
GET    /api/trip-stops/trip/{tripId}    - Get stops for trip
POST   /api/trip-stops/trip/{tripId}    - Create stop
PUT    /api/trip-stops/{id}             - Update stop
DELETE /api/trip-stops/{id}             - Delete stop
```

#### Activity APIs
```
GET    /api/activities/trip-stop/{stopId}  - Get activities
POST   /api/activities/trip-stop/{stopId}  - Create activity
PUT    /api/activities/{id}                - Update activity
DELETE /api/activities/{id}                - Delete activity
```

#### Budget APIs
```
GET    /api/budgets/trip/{tripId}              - Get budgets
GET    /api/budgets/trip/{tripId}/total        - Total budget
GET    /api/budgets/trip/{tripId}/by-category  - By category
POST   /api/budgets/trip/{tripId}              - Create budget
PUT    /api/budgets/{id}                       - Update budget
DELETE /api/budgets/{id}                       - Delete budget
```

#### Packing List APIs
```
GET    /api/packing-items/trip/{tripId}           - Get items
GET    /api/packing-items/trip/{tripId}/progress  - Progress
POST   /api/packing-items/trip/{tripId}           - Create item
PATCH  /api/packing-items/{id}/toggle             - Toggle packed
PUT    /api/packing-items/{id}                    - Update item
DELETE /api/packing-items/{id}                    - Delete item
```

---

## 🚀 Running the Application

### Frontend (React)
The frontend is already running in Figma Make preview. The multi-language support is active!

**To switch languages:**
1. Click the globe icon (🌐) in the sidebar
2. Select your preferred language
3. The entire app will update instantly

### Backend (Java Spring Boot)

**Prerequisites:**
- Java 17 or higher
- Maven 3.6 or higher

**Steps:**
```bash
# Navigate to backend directory
cd backend

# Build the project
mvn clean install

# Run the application
mvn spring-boot:run
```

**Access Points:**
- API Base: `http://localhost:8080/api`
- H2 Console: `http://localhost:8080/h2-console`
  - JDBC URL: `jdbc:h2:mem:travaloopdb`
  - Username: `sa`
  - Password: (empty)

---

## 🎨 Features Implemented

### Frontend Features
✅ **Authentication**
- Login & Signup pages
- Multi-language support on auth screens

✅ **Dashboard**
- Welcome message with stats
- Recent trips display
- Recommended destinations
- Quick trip creation

✅ **Trip Management**
- View all trips
- Create new trips
- Edit/delete trips
- Trip details view

✅ **Itinerary Builder**
- Multi-city planning
- Add/remove stops
- Activity scheduling
- Drag-and-drop ordering

✅ **Budget Tracking**
- Expense categorization
- Interactive pie charts
- Category summaries
- Detailed expense list

✅ **Packing List**
- Categorized items
- Progress tracking
- Pack/unpack toggle
- Add/remove items

✅ **City & Activity Search**
- Search functionality
- Filters (region, type, cost)
- Add to trip feature

✅ **User Profile**
- Profile editing
- Stats display
- Saved destinations
- Language preferences

### Backend Features
✅ **Complete REST API**
- Full CRUD operations for all entities
- Relational data management
- Query optimization

✅ **Database**
- JPA/Hibernate ORM
- H2 for development
- PostgreSQL ready for production

✅ **Validation**
- Input validation
- Error handling
- Data integrity

✅ **CORS Support**
- Cross-origin requests enabled
- Frontend integration ready

---

## 📁 Project Structure

```
/workspaces/default/code/
├── src/app/                          # Frontend React App
│   ├── components/
│   │   └── LanguageSwitcher.tsx      # Language selector
│   ├── context/
│   │   └── LanguageContext.tsx       # i18n context
│   ├── i18n/
│   │   └── translations.ts           # All translations
│   ├── pages/
│   │   ├── Login.tsx
│   │   ├── Dashboard.tsx
│   │   ├── MyTrips.tsx
│   │   ├── CreateTrip.tsx
│   │   ├── TripDetails.tsx
│   │   ├── ItineraryBuilder.tsx
│   │   ├── BudgetBreakdown.tsx
│   │   ├── PackingList.tsx
│   │   ├── CitySearch.tsx
│   │   ├── ActivitySearch.tsx
│   │   ├── UserProfile.tsx
│   │   └── NotFound.tsx
│   ├── routes.tsx                    # React Router config
│   └── App.tsx                       # Main app component
│
├── backend/                          # Java Spring Boot Backend
│   ├── src/main/java/com/traveloop/
│   │   ├── TravaloopApplication.java
│   │   ├── model/                    # Entity models
│   │   ├── repository/               # Data repositories
│   │   ├── service/                  # Business logic
│   │   ├── controller/               # REST controllers
│   │   └── config/                   # Configuration
│   ├── src/main/resources/
│   │   └── application.properties
│   ├── pom.xml                       # Maven config
│   └── README.md                     # Backend docs
│
└── PROJECT_SUMMARY.md                # This file
```

---

## 🔄 Connecting Frontend to Backend

To connect the React frontend to the Java backend:

1. **Update API calls in React:**
```typescript
// Example API call
const response = await fetch('http://localhost:8080/api/trips/user/1');
const trips = await response.json();
```

2. **CORS is already configured** in the backend

3. **Use environment variables:**
```typescript
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080/api';
```

---

## 🌟 Next Steps

### Recommended Enhancements
1. **Authentication**
   - Implement JWT tokens
   - Secure password hashing (BCrypt)
   - Session management

2. **File Upload**
   - Profile pictures
   - Trip cover images
   - Activity photos

3. **Real-time Features**
   - WebSocket for collaborative planning
   - Live updates

4. **External Integrations**
   - Weather API
   - Flight search
   - Hotel booking

5. **Advanced Features**
   - Trip sharing with friends
   - Collaborative editing
   - Export itinerary to PDF
   - Calendar integration

---

## 📚 Technology Stack Summary

### Frontend
- **React 18** - UI framework
- **TypeScript** - Type safety
- **React Router 7** - Navigation
- **Tailwind CSS 4** - Styling
- **Recharts** - Data visualization
- **Lucide React** - Icons
- **Context API** - State management

### Backend
- **Java 17** - Programming language
- **Spring Boot 3.2** - Framework
- **Spring Data JPA** - ORM
- **H2 Database** - Development DB
- **PostgreSQL** - Production DB (ready)
- **Lombok** - Code generation
- **Maven** - Build tool

---

## 🎓 Learning Resources

### Multi-language (i18n)
- React Context API documentation
- i18n best practices
- RTL support for Arabic/Hebrew

### Spring Boot
- [Spring Boot Official Docs](https://spring.io/projects/spring-boot)
- [Spring Data JPA Guide](https://spring.io/guides/gs/accessing-data-jpa/)
- [RESTful Web Services](https://spring.io/guides/gs/rest-service/)

---

## 📝 License
MIT License - Feel free to use this project for learning or commercial purposes!

---

## 🙌 Credits
Built with ❤️ for the Traveloop Hackathon
