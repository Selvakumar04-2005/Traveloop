package com.traveloop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Traveloop Application - Travel Planning Platform
 * Main Spring Boot Application Entry Point
 */
@SpringBootApplication
public class TravaloopApplication {

    public static void main(String[] args) {
        SpringApplication.run(TravaloopApplication.class, args);
        System.out.println("\n========================================");
        System.out.println("🌍 Traveloop Backend Server Started!");
        System.out.println("📍 API Base URL: http://localhost:8080/api");
        System.out.println("📊 H2 Console: http://localhost:8080/h2-console");
        System.out.println("========================================\n");
    }
}
