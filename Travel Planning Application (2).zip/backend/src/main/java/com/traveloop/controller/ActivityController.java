package com.traveloop.controller;

import com.traveloop.model.Activity;
import com.traveloop.model.TripStop;
import com.traveloop.repository.ActivityRepository;
import com.traveloop.repository.TripStopRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/activities")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ActivityController {

    private final ActivityRepository activityRepository;
    private final TripStopRepository tripStopRepository;

    @GetMapping("/trip-stop/{tripStopId}")
    public ResponseEntity<List<Activity>> getActivitiesByTripStopId(@PathVariable Long tripStopId) {
        List<Activity> activities = activityRepository.findByTripStopIdOrderByActivityOrderAsc(tripStopId);
        return ResponseEntity.ok(activities);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Activity> getActivityById(@PathVariable Long id) {
        Activity activity = activityRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Activity not found with id: " + id));
        return ResponseEntity.ok(activity);
    }

    @PostMapping("/trip-stop/{tripStopId}")
    public ResponseEntity<Activity> createActivity(@Valid @RequestBody Activity activity, @PathVariable Long tripStopId) {
        TripStop tripStop = tripStopRepository.findById(tripStopId)
                .orElseThrow(() -> new RuntimeException("Trip stop not found with id: " + tripStopId));
        activity.setTripStop(tripStop);
        Activity savedActivity = activityRepository.save(activity);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedActivity);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Activity> updateActivity(@PathVariable Long id, @Valid @RequestBody Activity activityDetails) {
        Activity activity = activityRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Activity not found with id: " + id));

        activity.setName(activityDetails.getName());
        activity.setDescription(activityDetails.getDescription());
        activity.setActivityType(activityDetails.getActivityType());
        activity.setStartTime(activityDetails.getStartTime());
        activity.setDuration(activityDetails.getDuration());
        activity.setCost(activityDetails.getCost());
        activity.setActivityOrder(activityDetails.getActivityOrder());

        Activity updatedActivity = activityRepository.save(activity);
        return ResponseEntity.ok(updatedActivity);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteActivity(@PathVariable Long id) {
        Activity activity = activityRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Activity not found with id: " + id));
        activityRepository.delete(activity);
        return ResponseEntity.noContent().build();
    }
}
