package com.traveloop.controller;

import com.traveloop.model.Budget;
import com.traveloop.model.Trip;
import com.traveloop.repository.BudgetRepository;
import com.traveloop.repository.TripRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/budgets")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class BudgetController {

    private final BudgetRepository budgetRepository;
    private final TripRepository tripRepository;

    @GetMapping("/trip/{tripId}")
    public ResponseEntity<List<Budget>> getBudgetsByTripId(@PathVariable Long tripId) {
        List<Budget> budgets = budgetRepository.findByTripId(tripId);
        return ResponseEntity.ok(budgets);
    }

    @GetMapping("/trip/{tripId}/total")
    public ResponseEntity<Map<String, Double>> getTotalBudget(@PathVariable Long tripId) {
        Double total = budgetRepository.getTotalBudgetByTripId(tripId);
        Map<String, Double> response = new HashMap<>();
        response.put("total", total != null ? total : 0.0);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/trip/{tripId}/by-category")
    public ResponseEntity<List<Object[]>> getBudgetByCategory(@PathVariable Long tripId) {
        List<Object[]> categoryBudgets = budgetRepository.getBudgetByCategory(tripId);
        return ResponseEntity.ok(categoryBudgets);
    }

    @PostMapping("/trip/{tripId}")
    public ResponseEntity<Budget> createBudget(@Valid @RequestBody Budget budget, @PathVariable Long tripId) {
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new RuntimeException("Trip not found with id: " + tripId));
        budget.setTrip(trip);
        Budget savedBudget = budgetRepository.save(budget);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedBudget);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Budget> updateBudget(@PathVariable Long id, @Valid @RequestBody Budget budgetDetails) {
        Budget budget = budgetRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Budget not found with id: " + id));

        budget.setCategory(budgetDetails.getCategory());
        budget.setItem(budgetDetails.getItem());
        budget.setAmount(budgetDetails.getAmount());
        budget.setDate(budgetDetails.getDate());
        budget.setNotes(budgetDetails.getNotes());

        Budget updatedBudget = budgetRepository.save(budget);
        return ResponseEntity.ok(updatedBudget);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBudget(@PathVariable Long id) {
        Budget budget = budgetRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Budget not found with id: " + id));
        budgetRepository.delete(budget);
        return ResponseEntity.noContent().build();
    }
}
