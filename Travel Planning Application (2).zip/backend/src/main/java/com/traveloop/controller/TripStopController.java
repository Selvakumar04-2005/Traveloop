package com.traveloop.controller;

import com.traveloop.model.Trip;
import com.traveloop.model.TripStop;
import com.traveloop.repository.TripRepository;
import com.traveloop.repository.TripStopRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trip-stops")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class TripStopController {

    private final TripStopRepository tripStopRepository;
    private final TripRepository tripRepository;

    @GetMapping("/trip/{tripId}")
    public ResponseEntity<List<TripStop>> getTripStopsByTripId(@PathVariable Long tripId) {
        List<TripStop> stops = tripStopRepository.findByTripIdOrderByStopOrderAsc(tripId);
        return ResponseEntity.ok(stops);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TripStop> getTripStopById(@PathVariable Long id) {
        TripStop stop = tripStopRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trip stop not found with id: " + id));
        return ResponseEntity.ok(stop);
    }

    @PostMapping("/trip/{tripId}")
    public ResponseEntity<TripStop> createTripStop(@Valid @RequestBody TripStop tripStop, @PathVariable Long tripId) {
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new RuntimeException("Trip not found with id: " + tripId));
        tripStop.setTrip(trip);
        TripStop savedStop = tripStopRepository.save(tripStop);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedStop);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TripStop> updateTripStop(@PathVariable Long id, @Valid @RequestBody TripStop stopDetails) {
        TripStop stop = tripStopRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trip stop not found with id: " + id));

        stop.setCity(stopDetails.getCity());
        stop.setCountry(stopDetails.getCountry());
        stop.setStartDate(stopDetails.getStartDate());
        stop.setEndDate(stopDetails.getEndDate());
        stop.setStopOrder(stopDetails.getStopOrder());
        stop.setNotes(stopDetails.getNotes());

        TripStop updatedStop = tripStopRepository.save(stop);
        return ResponseEntity.ok(updatedStop);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTripStop(@PathVariable Long id) {
        TripStop stop = tripStopRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trip stop not found with id: " + id));
        tripStopRepository.delete(stop);
        return ResponseEntity.noContent().build();
    }
}
