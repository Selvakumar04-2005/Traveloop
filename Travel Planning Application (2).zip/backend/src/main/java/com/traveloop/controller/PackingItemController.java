package com.traveloop.controller;

import com.traveloop.model.PackingItem;
import com.traveloop.model.Trip;
import com.traveloop.repository.PackingItemRepository;
import com.traveloop.repository.TripRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/packing-items")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class PackingItemController {

    private final PackingItemRepository packingItemRepository;
    private final TripRepository tripRepository;

    @GetMapping("/trip/{tripId}")
    public ResponseEntity<List<PackingItem>> getPackingItemsByTripId(@PathVariable Long tripId) {
        List<PackingItem> items = packingItemRepository.findByTripId(tripId);
        return ResponseEntity.ok(items);
    }

    @GetMapping("/trip/{tripId}/progress")
    public ResponseEntity<Map<String, Object>> getPackingProgress(@PathVariable Long tripId) {
        Long packedCount = packingItemRepository.countByTripIdAndIsPacked(tripId, true);
        Long totalCount = (long) packingItemRepository.findByTripId(tripId).size();

        Map<String, Object> response = new HashMap<>();
        response.put("packed", packedCount);
        response.put("total", totalCount);
        response.put("percentage", totalCount > 0 ? (packedCount * 100.0 / totalCount) : 0);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/trip/{tripId}")
    public ResponseEntity<PackingItem> createPackingItem(@Valid @RequestBody PackingItem item, @PathVariable Long tripId) {
        Trip trip = tripRepository.findById(tripId)
                .orElseThrow(() -> new RuntimeException("Trip not found with id: " + tripId));
        item.setTrip(trip);
        PackingItem savedItem = packingItemRepository.save(item);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedItem);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PackingItem> updatePackingItem(@PathVariable Long id, @Valid @RequestBody PackingItem itemDetails) {
        PackingItem item = packingItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Packing item not found with id: " + id));

        item.setName(itemDetails.getName());
        item.setCategory(itemDetails.getCategory());
        item.setIsPacked(itemDetails.getIsPacked());

        PackingItem updatedItem = packingItemRepository.save(item);
        return ResponseEntity.ok(updatedItem);
    }

    @PatchMapping("/{id}/toggle")
    public ResponseEntity<PackingItem> togglePacked(@PathVariable Long id) {
        PackingItem item = packingItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Packing item not found with id: " + id));

        item.setIsPacked(!item.getIsPacked());
        PackingItem updatedItem = packingItemRepository.save(item);
        return ResponseEntity.ok(updatedItem);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePackingItem(@PathVariable Long id) {
        PackingItem item = packingItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Packing item not found with id: " + id));
        packingItemRepository.delete(item);
        return ResponseEntity.noContent().build();
    }
}
