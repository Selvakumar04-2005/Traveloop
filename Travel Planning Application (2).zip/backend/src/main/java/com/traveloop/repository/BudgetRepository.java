package com.traveloop.repository;

import com.traveloop.model.Budget;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BudgetRepository extends JpaRepository<Budget, Long> {
    List<Budget> findByTripId(Long tripId);

    @Query("SELECT SUM(b.amount) FROM Budget b WHERE b.trip.id = :tripId")
    Double getTotalBudgetByTripId(Long tripId);

    @Query("SELECT b.category, SUM(b.amount) FROM Budget b WHERE b.trip.id = :tripId GROUP BY b.category")
    List<Object[]> getBudgetByCategory(Long tripId);
}
