package com.traveloop.repository;

import com.traveloop.model.PackingItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PackingItemRepository extends JpaRepository<PackingItem, Long> {
    List<PackingItem> findByTripId(Long tripId);
    List<PackingItem> findByTripIdAndCategory(Long tripId, String category);
    Long countByTripIdAndIsPacked(Long tripId, Boolean isPacked);
}
