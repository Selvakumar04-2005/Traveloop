package com.traveloop.repository;

import com.traveloop.model.Trip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TripRepository extends JpaRepository<Trip, Long> {
    List<Trip> findByUserId(Long userId);
    List<Trip> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<Trip> findByIsPublicTrue();
}
