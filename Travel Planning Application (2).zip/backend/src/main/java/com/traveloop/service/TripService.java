package com.traveloop.service;

import com.traveloop.model.Trip;
import com.traveloop.model.User;
import com.traveloop.repository.TripRepository;
import com.traveloop.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TripService {

    private final TripRepository tripRepository;
    private final UserRepository userRepository;

    public List<Trip> getAllTrips() {
        return tripRepository.findAll();
    }

    public Trip getTripById(Long id) {
        return tripRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Trip not found with id: " + id));
    }

    public List<Trip> getTripsByUserId(Long userId) {
        return tripRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public List<Trip> getPublicTrips() {
        return tripRepository.findByIsPublicTrue();
    }

    @Transactional
    public Trip createTrip(Trip trip, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
        trip.setUser(user);
        return tripRepository.save(trip);
    }

    @Transactional
    public Trip updateTrip(Long id, Trip tripDetails) {
        Trip trip = getTripById(id);
        trip.setName(tripDetails.getName());
        trip.setDescription(tripDetails.getDescription());
        trip.setStartDate(tripDetails.getStartDate());
        trip.setEndDate(tripDetails.getEndDate());
        trip.setCoverImageUrl(tripDetails.getCoverImageUrl());
        trip.setTotalBudget(tripDetails.getTotalBudget());
        trip.setIsPublic(tripDetails.getIsPublic());
        return tripRepository.save(trip);
    }

    @Transactional
    public void deleteTrip(Long id) {
        Trip trip = getTripById(id);
        tripRepository.delete(trip);
    }

    public Long getTotalTripsCount(Long userId) {
        return (long) tripRepository.findByUserId(userId).size();
    }
}
