# Traveloop Backend - Spring Boot REST API

## Overview
This is the backend API for Traveloop, a comprehensive travel planning application built with Spring Boot, JPA, and H2/PostgreSQL database.

## Technology Stack
- **Java**: 17
- **Spring Boot**: 3.2.0
- **Spring Data JPA**: Database operations
- **H2 Database**: In-memory database for development
- **PostgreSQL**: Production database support
- **Lombok**: Reduce boilerplate code
- **Maven**: Build and dependency management

## Project Structure
```
backend/
├── src/main/java/com/traveloop/
│   ├── TravaloopApplication.java       # Main application entry point
│   ├── model/                          # Entity models
│   │   ├── User.java
│   │   ├── Trip.java
│   │   ├── TripStop.java
│   │   ├── Activity.java
│   │   ├── Budget.java
│   │   └── PackingItem.java
│   ├── repository/                     # JPA repositories
│   │   ├── UserRepository.java
│   │   ├── TripRepository.java
│   │   ├── TripStopRepository.java
│   │   ├── ActivityRepository.java
│   │   ├── BudgetRepository.java
│   │   └── PackingItemRepository.java
│   ├── service/                        # Business logic
│   │   └── TripService.java
│   ├── controller/                     # REST endpoints
│   │   ├── UserController.java
│   │   ├── TripController.java
│   │   ├── TripStopController.java
│   │   ├── ActivityController.java
│   │   ├── BudgetController.java
│   │   └── PackingItemController.java
│   └── config/                         # Configuration
│       └── CorsConfig.java
└── src/main/resources/
    └── application.properties          # Application configuration
```

## Database Schema

### Tables
1. **users** - User authentication and profile
2. **trips** - Trip information
3. **trip_stops** - Cities/destinations in a trip
4. **activities** - Activities planned for each stop
5. **budgets** - Budget tracking for trips
6. **packing_items** - Packing checklist items

## API Endpoints

### User Management
- `POST /api/users/register` - Register new user
- `POST /api/users/login` - User login
- `GET /api/users/{id}` - Get user by ID
- `PUT /api/users/{id}` - Update user profile
- `DELETE /api/users/{id}` - Delete user

### Trip Management
- `GET /api/trips` - Get all trips
- `GET /api/trips/{id}` - Get trip by ID
- `GET /api/trips/user/{userId}` - Get trips by user
- `GET /api/trips/public` - Get public trips
- `POST /api/trips/user/{userId}` - Create new trip
- `PUT /api/trips/{id}` - Update trip
- `DELETE /api/trips/{id}` - Delete trip

### Trip Stops (Destinations)
- `GET /api/trip-stops/trip/{tripId}` - Get stops for a trip
- `GET /api/trip-stops/{id}` - Get stop by ID
- `POST /api/trip-stops/trip/{tripId}` - Create new stop
- `PUT /api/trip-stops/{id}` - Update stop
- `DELETE /api/trip-stops/{id}` - Delete stop

### Activities
- `GET /api/activities/trip-stop/{tripStopId}` - Get activities for a stop
- `GET /api/activities/{id}` - Get activity by ID
- `POST /api/activities/trip-stop/{tripStopId}` - Create new activity
- `PUT /api/activities/{id}` - Update activity
- `DELETE /api/activities/{id}` - Delete activity

### Budget Management
- `GET /api/budgets/trip/{tripId}` - Get all budgets for a trip
- `GET /api/budgets/trip/{tripId}/total` - Get total budget
- `GET /api/budgets/trip/{tripId}/by-category` - Get budget by category
- `POST /api/budgets/trip/{tripId}` - Create budget entry
- `PUT /api/budgets/{id}` - Update budget
- `DELETE /api/budgets/{id}` - Delete budget

### Packing List
- `GET /api/packing-items/trip/{tripId}` - Get packing items for a trip
- `GET /api/packing-items/trip/{tripId}/progress` - Get packing progress
- `POST /api/packing-items/trip/{tripId}` - Create packing item
- `PUT /api/packing-items/{id}` - Update packing item
- `PATCH /api/packing-items/{id}/toggle` - Toggle packed status
- `DELETE /api/packing-items/{id}` - Delete packing item

## Running the Application

### Prerequisites
- Java 17 or higher
- Maven 3.6 or higher

### Build and Run
```bash
# Navigate to backend directory
cd backend

# Build the project
mvn clean install

# Run the application
mvn spring-boot:run
```

The server will start on **http://localhost:8080**

### Access H2 Console
- URL: http://localhost:8080/h2-console
- JDBC URL: jdbc:h2:mem:travaloopdb
- Username: sa
- Password: (leave empty)

## Configuration

### Development (H2 Database)
The application uses H2 in-memory database by default. Configuration in `application.properties`:

```properties
spring.datasource.url=jdbc:h2:mem:travaloopdb
spring.datasource.username=sa
spring.datasource.password=
```

### Production (PostgreSQL)
To use PostgreSQL, update `application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/travaloopdb
spring.datasource.username=your_username
spring.datasource.password=your_password
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect
```

## Features Implemented

### User Management
- User registration and authentication
- Profile management
- Multi-language support

### Trip Planning
- Create and manage trips
- Multi-city itineraries
- Date range planning
- Public/private trip visibility

### Itinerary Building
- Add multiple destinations (stops)
- Activity planning for each stop
- Time and cost tracking
- Reorderable stops and activities

### Budget Tracking
- Category-based expense tracking
- Budget summaries
- Cost breakdown by category
- Total budget calculation

### Packing List
- Categorized packing items
- Pack/unpack toggle
- Progress tracking
- Category organization

## API Response Format

### Success Response
```json
{
  "id": 1,
  "name": "European Adventure",
  "startDate": "2026-06-15",
  "endDate": "2026-06-30"
}
```

### Error Response
```json
{
  "timestamp": "2026-05-10T10:30:00",
  "status": 404,
  "error": "Not Found",
  "message": "Trip not found with id: 1"
}
```

## Testing
```bash
# Run tests
mvn test

# Run with coverage
mvn clean test jacoco:report
```

## Docker Support (Optional)
```dockerfile
# Dockerfile example
FROM openjdk:17-jdk-slim
WORKDIR /app
COPY target/traveloop-backend-1.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

## Future Enhancements
- JWT-based authentication
- Role-based access control
- File upload for images
- Email notifications
- Real-time collaboration
- Integration with external APIs (weather, flights, hotels)
- GraphQL support
- Caching with Redis
- Message queue integration

## Contributing
1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## License
This project is licensed under the MIT License.

## Contact
For questions or support, please contact the development team.
