
  # Travel Planning Application

  This is a code bundle for Travel Planning Application. The original project is available at https://www.figma.com/design/6kve3qVyt832GaTKsvY7GV/Travel-Planning-Application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  